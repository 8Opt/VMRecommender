# AI Assessment

## Description

This project aims to build a dynamic network diagram generator using a Retrieval Augmented Generation (RAG) system. By leveraging a database of VM types, we'll design a workflow that takes customer specifications as input and produces a JSON output representing a complete network diagram. This includes the allocation of virtual machines, VLAN configuration, and the specific details of each chosen machine type. This approach promises a highly automated and flexible solution for creating tailored network diagrams based on customer needs.


### Technology

I chose LangChain framework for building this application.LangChain offers pre-built chains and modules for common tasks, simplifies data handling with integration with libraries like Pydantic, and benefits from an active community and ecosystem. For this network diagram generator project, LangChain can help this project access data from the VM database, generate JSON output, and adapt this workflow as the project evolves. Gemini is my “de-facto” choice for this project as a LLM agent. It is free and powerful in understanding. For vector database, I chose ChromaDB. 

### Difficulties

+ Not all users can define their desired specifications clearly


### Future developments

+ Transcript user's descriptions that can match the dataset.
+ Create an agent that can be described as a business analyst: know what user need and know what the company has.

## Usage

1. Install requirement via the command line: 

```
pip install -r requirements.txt
```

2. Create a `.env` file and get the GEMINI's API key from Google AI Studio. 

```
GEMINI_API_KEY = "GEMINI_API_KEY"

```

3. Depends on your usage, you can call the `get_network_description` from `chain.py` for direct uses. Or you can test if the model can perfrom or not with `test_rag.py`. 
I suggest using `Streamlit` app. 

Try this sample: I want a network diagram that clearly illustrates our security posture. I need to see how our firewalls are configured and where they sit within the network, along with any other security devices like intrusion detection systems (IDS). I'd like to see the flow of traffic between our internal network and the internet, showing any DMZs or other segmentation measures. The diagram should also highlight any potential vulnerabilities, like open ports or exposed services, so we can prioritize remediation efforts.

```
streamlit run app.py

```

## Gallery

![sample1](./notebook/static/Screenshot from 2024-07-03 17-44-09.png)

![sample2](./notebook/static/Screenshot from 2024-07-03 17-44-13.png)

![sample3](./notebook/static/Screenshot from 2024-07-03 17-44-15.png)

## Note

Detailed information are discussed in this [docs](https://docs.google.com/document/d/17-qVIwwIJqz9RrdrdYGJnJd7La-GJjVSGpHp5lnIyTw/edit?usp=sharing)