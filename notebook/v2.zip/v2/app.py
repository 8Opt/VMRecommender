import os 
from dotenv import load_dotenv

import streamlit as st
from src.chain import get_network_description

load_dotenv()
os.environ['GOOGLE_API_KEY'] = os.getenv('GEMINI_API_KEY')


st.header("[ECQ: AI Assessment]")
st.subheader("Design and implement a workflow that generates a network diagram featuring virtual machines (VMs) based on customer specifications")
st.divider()


desc = st.text_input(label="Please type")
if st.button("Submit"):
    response = get_network_description(desc=desc, use_rag=True)
    st.json(response)
