from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser

from src.agent import llm
from src.prompts import base_template, output_sample, rag_template
from src.schema import NetworkConfig
from src.tools import dict_to_json
from src.retriever import get_chunked_docs, get_docs_loader, get_retriever

data_dir = './vm_info.csv'
json_parser = JsonOutputParser(pydantic_object=NetworkConfig)

def get_network_description(desc:str, use_rag:bool=True, to_json:bool=True):     

    if use_rag: 
        docs = get_docs_loader()
        splits = get_chunked_docs(docs)
        retriever = get_retriever(splits)

        rag_prompt = PromptTemplate.from_template(rag_template, 
                                            partial_variables={"format_instructions": json_parser.get_format_instructions()})
        chain = (
            {"context": retriever, "json_data": lambda x: output_sample, "question": RunnablePassthrough()}
            | rag_prompt
            | llm
            | json_parser
        )
    else: 
        template = PromptTemplate.from_template(base_template, 
                                                partial_variables={"format_instructions": json_parser.get_format_instructions()})
        chain = (
            {"json_data": lambda x: output_sample, "question": RunnablePassthrough()}
            | template
            | llm
            | json_parser
        )

    result = chain.invoke(input=desc)
    if to_json: 
        return dict_to_json(result)
    return result

if __name__ == "__main__": 
    sample = "I want a network diagram that clearly illustrates our security posture. I need to see how our firewalls are configured and where they sit within the network, along with any other security devices like intrusion detection systems (IDS). I'd like to see the flow of traffic between our internal network and the internet, showing any DMZs or other segmentation measures. The diagram should also highlight any potential vulnerabilities, like open ports or exposed services, so we can prioritize remediation efforts."
    result = get_network_description(sample,
                                     use_rag=True)
    print(result)