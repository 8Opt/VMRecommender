rag_template = """
Your task is to design and implement a workflow that generates a network diagram featuring
virtual machines (VMs) based on customer specifications. The workflow should use a database
of VM types, detailing their descriptions, minimum specifications, and installed software, and
produce a JSON output that represents the network diagram, including VLANs and the specified
machines.


Sample Responses:
{json_data}


Question: {question} 

Context: {context} 

Do not answer out of the Sample Response schema.

Answer:

"""

base_template = """
Your task is to recommend for users based on their specifications. Based on information that you have:

Unique_ID,Platform,Distributor,Description,Min_CPU,Min_RAM_GB,Min_Storage_GB,Installed_Software,Image_Version
1,Windows,Windows Server,"A general-purpose VM suitable for Windows-based workloads",2,4,50,"OS:Windows Server 2019, IIS:10.0, SQL Server:2019",2019
2,Linux,Ubuntu,"A lightweight VM for Linux development environments",1,2,20,"OS:Ubuntu 20.04, Apache:2.4, MySQL:8.0",20.04
3,Windows,Windows Pro,"High-performance VM for Windows desktop applications",4,8,100,"OS:Windows 10 Pro, Office:2019, Visual Studio:2019",win10_pro
4,Linux,CentOS,"Stable and secure VM for server applications",2,4,50,"OS:CentOS 8, Nginx:1.18, PostgreSQL:13",centos_8
5,MacOS,MacOS,"High-end VM for macOS development and testing",4,16,200,"OS:macOS Catalina, Xcode:12.4, Homebrew:2.7",10.15
6,Linux,Ubuntu,"Compute-optimized VM with a high CPU-to-memory ratio",4,8,100,"OS:Ubuntu 20.04, Docker:20.10, Kubernetes:1.20",20.04
7,Windows,Windows Server,"High memory capacity VM for in-memory databases on Windows",4,16,200,"OS:Windows Server 2019, Redis:6.0, MongoDB:4.4",2019
8,Linux,CentOS,"Storage-optimized VM for data warehousing",2,8,500,"OS:CentOS 8, Hadoop:3.2, Spark:3.0",centos_8_storage
9,Windows,Windows Pro,"Graphics-optimized VM for GPU-accelerated Windows applications",8,32,1000,"OS:Windows 10 Pro, CUDA:11.2, TensorFlow:2.4",win10_pro_gpu
10,MacOS,MacOS,"VM for macOS graphics and video editing",8,32,1000,"OS:macOS Catalina, Final Cut Pro:10.5, Adobe Creative Suite:2020",macos_10.15
11,Linux,Ubuntu,"Web application server optimized for hosting web apps",2,4,50,"OS:Ubuntu 20.04, Apache:2.4, PHP:7.4, MySQL:8.0",20.04_web
12,Linux,CentOS,"Database server optimized for high-performance databases",4,16,100,"OS:CentOS 8, MySQL:8.0, PostgreSQL:13",8
13,Windows,Windows Server,"Firewall server for network security and traffic monitoring",2,4,50,"OS:Windows Server 2019, Windows Defender:10.0, Firewall Software:2.0",2019
14,Linux,Ubuntu,"Firewall server for network security and traffic monitor3ing",2,4,50,"OS:Ubuntu 20.04, UFW:0.36, FirewallD:0.8",20.04_firewall
15,Windows,Windows Server,"High-performance VM for Windows-based web applications",4,8,100,"OS:Windows Server 2019, IIS:10.0, ASP.NET:4.8",2019_server
16,Linux,CentOS,"Database server optimized for big data applications",4,16,200,"OS:CentOS 8, Cassandra:3.11, HBase:2.2",centos_8_database

Question: {question} 
 
You must folow the JSON format. Your generated answer must be like this: 

{json_data}

Do not say anything out of the example's scope.

"""

output_sample = """
{
"action": "create",
"env_id": "9876abdc5432",
"network_portgroup": {
"pg1": {
"allow_promiscuous": true,
"default_gateway": "192.168.1.1",
"dhcp_range": [
"192.168.1.100",
"192.168.1.200"
],
"netmask": "24",
"pg_name": "pg1",
"subnet": "192.168.1.0",
"vlan_id": 10
},
"pg2": {
"allow_promiscuous": true,
"default_gateway": "10.0.0.1",
"dhcp_range": [
"10.0.0.100",
"10.0.0.200"
],
"netmask": "24",
"pg_name": "pg2",
"subnet": "10.0.0.0",
"vlan_id": 20
}
},
"resource_id": "abcdef123456",
"vm_instance": {
"vm1": {
"cpu_number": "4",
"disk_size_gb": "100",
"gateway": "192.168.1.1",
"hostname": "web-server",
"image": "ubuntu",
"instance": 1,
"network": {
"eth0": {
"ipv4_address": [
"192.168.1.10"
],
"ipv4_netmask": ["24"
],
"portgroup": "pg1"
}
},
"os_version": "20.04",
"ram_size": "8192"
},
"vm2": {
"cpu_number": "2",
"disk_size_gb": "50",
"gateway": "10.0.0.1",
"hostname": "db-server",
"image": "centos",
"instance": 1,
"network": {
"eth0": {
"ipv4_address": [
"10.0.0.20"
],
"ipv4_netmask": [
"24"
],
"portgroup": "pg2"
}
},
"os_version": "8",
"ram_size": "4096"
}
}
}
"""