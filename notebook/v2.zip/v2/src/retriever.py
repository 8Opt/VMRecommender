import os 
from dotenv import load_dotenv

from langchain_chroma import Chroma
from langchain_community.document_loaders.csv_loader import CSVLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings

load_dotenv()
os.environ['GOOGLE_API_KEY'] = os.getenv('GEMINI_API_KEY')


def get_docs_loader(dir='./vm_info.csv'): 
    loader = CSVLoader(file_path="./vm_info.csv")
    docs = loader.load()
    return docs

def get_chunked_docs(documents): 
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    splits = text_splitter.split_documents(documents)
    return splits

def get_retriever(docs): 
    vectorstore = Chroma.from_documents(documents=docs, embedding=GoogleGenerativeAIEmbeddings(model='models/embedding-001'))
    retriever = vectorstore.as_retriever()
    return retriever