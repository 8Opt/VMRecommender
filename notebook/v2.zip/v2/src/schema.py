from typing import List, Dict
from langchain_core.pydantic_v1 import BaseModel, Field, validator

class NetworkPortgroup(BaseModel):
    allow_promiscuous: bool
    default_gateway: str
    dhcp_range: List[str]
    netmask: str
    pg_name: str
    subnet: str
    vlan_id: int

class Network(BaseModel):
    eth0: Dict

class VMInstance(BaseModel):
    cpu_number: str
    disk_size_gb: str
    gateway: str
    hostname: str
    image: str
    instance: int
    network: Network
    os_version: str
    ram_size: str

    @validator('ram_size', pre=True)
    def convert_ram_size(cls, value):
        return int(value)

class NetworkConfig(BaseModel):
    action: str
    env_id: str
    network_portgroup: Dict[str, NetworkPortgroup]
    resource_id: str
    vm_instance: Dict[str, VMInstance]
