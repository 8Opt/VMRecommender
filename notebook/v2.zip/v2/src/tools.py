import json 

def dict_to_json(content: dict): 
    result = json.dumps(content, indent=4)
    return result
