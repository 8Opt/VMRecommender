import unittest
from chain import get_network_description
from samples import network_diagram_request_samples


class TestBaseSetting(unittest.TestCase): 
    def test_request_samples(self): 
        results = []
        for k, v in network_diagram_request_samples.items(): 
            result = isinstance(get_network_description(v, use_rag=False), str)
            results.append(result)

        print(results)
        self.assertIs(any(results), True)


if __name__ == '__main__':
    unittest.main()
