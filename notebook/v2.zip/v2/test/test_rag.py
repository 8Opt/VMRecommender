import unittest
from chain import get_network_description

network_diagram_request_samples = {
    "Security": "I want a network diagram that clearly illustrates our security posture. I need to see how our firewalls are configured and where they sit within the network, along with any other security devices like intrusion detection systems (IDS). I'd like to see the flow of traffic between our internal network and the internet, showing any DMZs or other segmentation measures. The diagram should also highlight any potential vulnerabilities, like open ports or exposed services, so we can prioritize remediation efforts.",

    "Scalability and Performance": "I want a network diagram that showcases how our network is designed to scale and handle increasing traffic. It should depict how our load balancers are set up and how they distribute traffic across multiple servers. I'd like to see the bandwidth of each connection and the capacity of our core network devices to understand any potential bottlenecks. The diagram should also clearly show how our network is segmented to optimize performance for specific applications, like our web server or database cluster.",

    "Cloud Integration": "I want a network diagram that illustrates how our on-premises infrastructure connects to our cloud services. It should show how our servers communicate with our cloud-based applications and databases, including any VPNs or dedicated connections. The diagram should also highlight any security measures we have in place for cloud access, like multi-factor authentication or cloud-based firewalls. Finally, I want to understand how our cloud provider's network architecture integrates with our own network.",

    "Collaboration and Communication": "I want a network diagram that maps out how our employees and teams collaborate and communicate using various technologies. It should show how our internal network connects to our voice over IP (VoIP) system, video conferencing platforms, and collaboration tools like Microsoft Teams or Slack. The diagram should also highlight any dedicated network segments for these applications to ensure optimal performance and minimize latency.",

    "Disaster Recovery and Business Continuity": "I want a network diagram that visualizes our disaster recovery plan and business continuity measures. It should show how our network is designed to handle outages and ensure critical services remain available. This includes identifying backup servers, redundant connections, and any failover mechanisms in place. The diagram should also clearly show how our data is replicated and backed up, both within our network and in the cloud, to ensure data integrity and business continuity.",
}

class TestRAGSetting(unittest.TestCase): 
    def test_request_samples(self): 
        results = []
        for k, v in network_diagram_request_samples.items(): 
            result = isinstance(get_network_description(v), str)
            results.append(result)

        print(results)
        self.assertIs(any(results), True)


if __name__ == '__main__':
    unittest.main()

"""
----------------------------------------------------------------------
Ran 1 test in 41.269s

OK
"""